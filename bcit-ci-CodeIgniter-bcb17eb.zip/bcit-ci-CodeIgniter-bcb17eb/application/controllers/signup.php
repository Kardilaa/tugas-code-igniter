<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class signup extends CI_Controller {

	
	public function index()
	{
		echo"HALAMAN DAFTAR";
	}
	public function login(){
		$this->load->view('login');
}
public function home(){

	$this->load->view('home');
}
public function register(){

	$this->load->view('register');
}
}